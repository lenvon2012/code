/* -*- coding: utf-8 -*-
 * ----------------------------------------------------------------------
 * Copyright © 2011, RedJack, LLC.
 * All rights reserved.
 *
 * Please see the COPYING file in this distribution for license
 * details.
 * ----------------------------------------------------------------------
 */

#ifndef LIBCORK_CONFIG_H
#define LIBCORK_CONFIG_H

/*** include all of the parts ***/

#include <libcork/config/config.h>

#endif /* LIBCORK_CONFIG_H */
