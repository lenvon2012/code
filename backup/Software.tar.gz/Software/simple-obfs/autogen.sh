#!/bin/sh

autoreconf268 --install --force
