一键脚本安装shadowsocks/shadowsocksR + 开启bbr
---

一键脚本搭建shadowsocks/shadowsocksR + 设置开启自启动 + 升级内核&开启bbr加速。

## 支持系统
CentOS 6+
Debian 7+
Ubuntu 12+

## 使用教程
[一键脚本搭建shadowsocks+开启bbr][1]


  [1]: https://www.flyzy2005.com/fan-qiang/shadowsocks/install-shadowsocks-in-one-command/
